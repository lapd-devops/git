This directory contains samples for VMC organization APIs:

Running the samples

    $ python organization_operations.py -r <refresh_token>

* Testbed Requirement:
   - At least one org associated with the calling user.

