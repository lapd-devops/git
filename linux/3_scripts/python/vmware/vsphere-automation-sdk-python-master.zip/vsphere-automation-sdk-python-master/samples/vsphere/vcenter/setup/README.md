This directory contains sample scripts to setup the testbed required to run
the vCenter APIs samples. Refer see [README](../../../../README.md#running-the-sdk-sample-setup-script) for more details.
