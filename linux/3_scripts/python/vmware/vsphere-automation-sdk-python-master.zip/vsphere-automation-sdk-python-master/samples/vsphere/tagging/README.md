This directory contains samples for Tagging APIs:

Running the samples

    $ python tagging_workflow.py --server <vCenter Server IP> --username <username> --password <password> --clustername <clustername> --categoryname <categoryname> --categorydesc <categorydesc> --tagname <tagname> -tagdesc <tagdesc> -v

* Testbed Requirement:
   - 1 vCenter Server
   - 1 cluster

