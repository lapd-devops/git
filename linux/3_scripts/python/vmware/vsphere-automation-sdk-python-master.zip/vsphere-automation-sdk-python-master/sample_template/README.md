Boilerplate code for new samples
================================

* For complex samples require setup and cleanup please use sample_template_complex.py    
* For simple samples which just demo basic API usage please use sample_template_basic.py
